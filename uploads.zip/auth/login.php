<?php
// Tambahkan di atas session_start()
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1); // Jika pakai HTTPS
session_start();
?>