<?php
// Redirect ke login page
header("Location: auth/login.php");
exit();
?>